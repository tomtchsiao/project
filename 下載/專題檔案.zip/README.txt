Guide of the project
---------------------------------------------------------------------

Using command line or terminal, please make sure that install Python.

Install flask package via pip.

> pip install flask 

Using python3 to execute the project.

> python3 app.py

Last, paste the URL (http://127.0.0.1:5000/) to browser.
