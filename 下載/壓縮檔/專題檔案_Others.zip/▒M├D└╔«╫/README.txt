Guide of the project

I. Using Windows / Mac / Linux command line / terminal, please make sure that install Python.

Install flask package via pip.

Next, type below command to view the result.

> pip install flask 
> python3 app.py

Last, paste the URL to browser.
